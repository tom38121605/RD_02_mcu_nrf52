#ifndef __M_KEY_H__
#define __M_KEY_H__

#include "nrf.h"
#include "stdint.h"




#define KEY1          16
#define KEY2          17

#define KEY1_STA() nrf_gpio_pin_read(KEY1)
#define KEY2_STA() nrf_gpio_pin_read(KEY2)


void init_key(void);
void exit_key_init(void);


#endif


