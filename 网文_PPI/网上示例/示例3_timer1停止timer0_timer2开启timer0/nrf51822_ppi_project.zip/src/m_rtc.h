#ifndef __M_RTC_H__
#define __M_RTC_H__

#include "nrf.h"
#include "stdint.h"




void lfclk_config(void);
void rtc_config(void);

void rtc_delay_ms(uint32_t ms);
void rtc_delay_30us(uint32_t us);




#endif


