#include "m_key.h"
#include "m_led.h"
#include "nrf_gpio.h"
#include "nrf_delay.h"


void init_key(void)
{
    nrf_gpio_cfg_input(KEY1,NRF_GPIO_PIN_PULLUP);
    nrf_gpio_cfg_input(KEY2,NRF_GPIO_PIN_PULLUP);
}

//EXIT_KEY_Init
void exit_key_init(void)
{

    nrf_gpio_cfg_input(KEY1,NRF_GPIO_PIN_PULLUP);


    NVIC_EnableIRQ(GPIOTE_IRQn);

    NRF_GPIOTE->CONFIG[0] =  (GPIOTE_CONFIG_POLARITY_HiToLo << GPIOTE_CONFIG_POLARITY_Pos)
                             | (16 << GPIOTE_CONFIG_PSEL_Pos)
                             | (GPIOTE_CONFIG_MODE_Event << GPIOTE_CONFIG_MODE_Pos);
    NRF_GPIOTE->INTENSET  = GPIOTE_INTENSET_IN0_Set << GPIOTE_INTENSET_IN0_Pos;
}


void GPIOTE_IRQHandler(void)
{

    if ((NRF_GPIOTE->EVENTS_IN[0] == 1) &&
            (NRF_GPIOTE->INTENSET & GPIOTE_INTENSET_IN0_Msk))
    {
        NRF_GPIOTE->EVENTS_IN[0] = 0;
        nrf_delay_ms(20);
        if (KEY1_STA()==0)
        {
            LED_TOG();
        }
    }

}
