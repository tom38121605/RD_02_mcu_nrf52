#ifndef __M_LED_H__
#define __M_LED_H__

#include "nrf.h"
#include "stdint.h"




#define LED_0          18


#define LED_ON() nrf_gpio_pin_write(LED_0,1)
#define LED_OFF() nrf_gpio_pin_write(LED_0,0)
#define LED_TOG() nrf_gpio_pin_toggle(LED_0)
void init_led(void);



#endif


