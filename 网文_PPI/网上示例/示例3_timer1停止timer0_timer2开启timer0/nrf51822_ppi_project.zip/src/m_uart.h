#ifndef __M_UART_H__
#define __M_UART_H__

#include "nrf.h"
#include "stdint.h"
#include "stdbool.h"



uint8_t simple_uart_get(void);
bool simple_uart_get_with_timeout(int32_t timeout_ms, uint8_t *rx_data);
void simple_uart_put(uint8_t cr);
void simple_uart_putstring(const uint8_t *str);
void simple_uart_config(  uint8_t rts_pin_number,
                          uint8_t txd_pin_number,
                          uint8_t cts_pin_number,
                          uint8_t rxd_pin_number,
                          bool    hwfc);
void uart_exit(void);





#endif


