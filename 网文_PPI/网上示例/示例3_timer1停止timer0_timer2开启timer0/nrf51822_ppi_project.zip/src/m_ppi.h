#ifndef __M_PPI_H__
#define __M_PPI_H__

#include "nrf.h"
#include "stdint.h"
#include "stdbool.h"



void ppi_timer_init(void);
void ppi_init(void);
void start_ppi(void);
void task_ppi(void);



#endif


