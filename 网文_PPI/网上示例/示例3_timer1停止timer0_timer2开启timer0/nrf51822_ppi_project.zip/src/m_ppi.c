#include "m_ppi.h"
#include "nrf_gpio.h"
#include "m_led.h"
#include "nrf_delay.h"
#include "m_uart.h"
#include "stdbool.h"
#include "stdio.h"


void ppi_timer_init(void)
{
	//timer0================================================================================
    NRF_TIMER0->MODE    = TIMER_MODE_MODE_Counter;      // Set the timer in counter Mode.
    NRF_TIMER0->BITMODE = TIMER_BITMODE_BITMODE_24Bit;  // 24-bit mode.
	
	//timer1================================================================================
	// Configure Timer 1 to overflow every 2 seconds.
    // SysClk = 16 Mhz
    // BITMODE = 16 bit
    // PRESCALER = 9
    // The overflow occurs every 0xFFFF/(SysClk/2^PRESCALER).
    // = 65535/31250 = 2.097 sec
    NRF_TIMER1->BITMODE     = (TIMER_BITMODE_BITMODE_16Bit << TIMER_BITMODE_BITMODE_Pos);
    NRF_TIMER1->PRESCALER   = 4;
    NRF_TIMER1->SHORTS      = (TIMER_SHORTS_COMPARE0_CLEAR_Enabled << TIMER_SHORTS_COMPARE0_CLEAR_Pos);

    // Trigger interrupt for compare[0] event.
    NRF_TIMER1->MODE        = TIMER_MODE_MODE_Timer;
    NRF_TIMER1->CC[0]       = 2*1000*1000;  // Match at even number of seconds
	
	
	
	
	//timer2================================================================================
	// Generate interrupt/event when half of time before the timer overflows has past, that is at 1,3,5,7... seconds from start.
    // SysClk = 16Mhz
    // BITMODE = 16 bit
    // PRESCALER = 9
    // now the overflow occurs every 0xFFFF/(SysClk/2^PRESCALER)
    // = 32767/31250 = 1.048544 sec */
    NRF_TIMER2->BITMODE     = (TIMER_BITMODE_BITMODE_16Bit << TIMER_BITMODE_BITMODE_Pos);
    NRF_TIMER2->PRESCALER   = 4;
    NRF_TIMER2->SHORTS      = (TIMER_SHORTS_COMPARE0_CLEAR_Enabled << TIMER_SHORTS_COMPARE0_CLEAR_Pos);

    // Trigger interrupt for compare[0] event.
    NRF_TIMER2->MODE        = TIMER_MODE_MODE_Timer;
    NRF_TIMER2->CC[0]       = 1000*1000;  // Match at odd number of seconds.
}

void ppi_init(void)
{
    // Configure PPI channel 0 to stop Timer 0 counter at TIMER1 COMPARE[0] match, which is every even number of seconds.
    NRF_PPI->CH[0].EEP = (uint32_t)(&NRF_TIMER1->EVENTS_COMPARE[0]);
    NRF_PPI->CH[0].TEP = (uint32_t)(&NRF_TIMER0->TASKS_STOP);

    // Configure PPI channel 1 to start timer0 counter at TIMER2 COMPARE[0] match, which is every odd number of seconds.
    NRF_PPI->CH[1].EEP = (uint32_t)(&NRF_TIMER2->EVENTS_COMPARE[0]);
    NRF_PPI->CH[1].TEP = (uint32_t)(&NRF_TIMER0->TASKS_START);

    // Enable only PPI channels 0 and 1.
    NRF_PPI->CHEN = (PPI_CHEN_CH0_Enabled << PPI_CHEN_CH0_Pos) | (PPI_CHEN_CH1_Enabled << PPI_CHEN_CH1_Pos);
}
void start_ppi(void)
{
    NRF_POWER->TASKS_CONSTLAT = 1;
    
    // Start clock.
    NRF_TIMER1->TASKS_START = 1;
    NRF_TIMER2->TASKS_START = 1;


}

void task_ppi(void)
{
	char buf[50];
	/* increment the counter */
	NRF_TIMER0->TASKS_COUNT         = 1;
	NRF_TIMER0->TASKS_CAPTURE[0]    = 1;

//	nrf_gpio_port_write(NRF_GPIO_PORT_SELECT_PORT1, (uint8_t)NRF_TIMER0->CC[0]);
	sprintf(buf,"cc:%d\r\n",NRF_TIMER0->CC[0]);
	simple_uart_putstring((const uint8_t *)buf);
	nrf_delay_ms(100);
}



