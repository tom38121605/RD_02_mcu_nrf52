#include "m_led.h"
#include "nrf_gpio.h"



void init_led(void)
{
	nrf_gpio_cfg_output(LED_0);
	LED_OFF();
}

