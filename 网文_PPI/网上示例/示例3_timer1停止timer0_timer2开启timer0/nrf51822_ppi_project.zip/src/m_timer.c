#include "m_rtc.h"
#include "nrf_gpio.h"
#include "m_led.h"
#include "stdbool.h"




void timer_init(void)
{
	
	// Start 16 MHz crystal oscillator .
    NRF_CLOCK->EVENTS_HFCLKSTARTED  = 0;
    NRF_CLOCK->TASKS_HFCLKSTART     = 1;

    // Wait for the external oscillator to start up.
    while (NRF_CLOCK->EVENTS_HFCLKSTARTED == 0) 
    {
        //Do nothing.
    }
	NRF_TIMER0->TASKS_STOP = 1;
	
	NVIC_EnableIRQ(TIMER0_IRQn);
	__enable_irq();
	NRF_TIMER0->TASKS_CLEAR = 1;
	NRF_TIMER0->SHORTS     = (TIMER_SHORTS_COMPARE0_CLEAR_Enabled << TIMER_SHORTS_COMPARE0_CLEAR_Pos);
	NRF_TIMER0->MODE           = TIMER_MODE_MODE_Timer;     
	NRF_TIMER0->BITMODE        = TIMER_BITMODE_BITMODE_32Bit;  
	NRF_TIMER0->PRESCALER     = 4;//1M       
	NRF_TIMER0->INTENSET   = (TIMER_INTENSET_COMPARE0_Set << TIMER_INTENSET_COMPARE0_Pos);
	NRF_TIMER0->CC[0]         = 1000*1000;  

	
	NRF_TIMER0->TASKS_START    = 1;                    
	

}

void TIMER0_IRQHandler()
{
    if ((NRF_TIMER0->EVENTS_COMPARE[0] != 0) && 
       ((NRF_TIMER0->INTENSET & TIMER_INTENSET_COMPARE0_Msk) != 0))
    {
        // Sets the next CC1 value
        NRF_TIMER0->EVENTS_COMPARE[0] = 0;
        LED_TOG();
    }
}













