#ifndef __M_TIMER_H__
#define __M_TIMER_H__

#include "nrf.h"
#include "stdint.h"


void timer_init(void);




#endif


