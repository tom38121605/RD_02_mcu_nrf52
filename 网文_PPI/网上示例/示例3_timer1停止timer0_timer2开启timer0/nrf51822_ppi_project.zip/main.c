
#include <stdbool.h>
#include "nrf_gpio.h"
#include "nrf_delay.h"
#include "m_rtc.h"
#include "m_led.h"
#include "m_key.h"
#include "m_timer.h"
#include "m_uart.h"
#include "m_ppi.h"


int main(void)
{
    ppi_timer_init();
    ppi_init();
    start_ppi();
	
	simple_uart_config(0xff,9,0xff,11,false);
	uart_exit();
	
    while(1)
    {
        task_ppi();
    }
}


//int main(void)
//{

//    lfclk_config();
////    rtc_config();
//    init_led();
////	timer_init();
//	simple_uart_config(0xff,9,0xff,11,false);
//	uart_exit();
//
//    while (true)
//    {
////		LED_ON();
////		rtc_delay_ms(1000);
////		LED_OFF();
////		rtc_delay_ms(1000);

//    }
//}




