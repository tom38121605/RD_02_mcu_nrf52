#ifndef _NRF_DELAY_H
#define _NRF_DELAY_H

#include "nrf.h"
#include "stdint.h"


static __ASM void __INLINE nrf_delay_us(uint32_t volatile number_of_us)
{
loop
        SUBS    R0, R0, #1
        NOP
        NOP
        NOP
        NOP
        NOP
        NOP
        NOP
        NOP
        NOP
        NOP
        NOP
        NOP
        BNE    loop
        BX     LR
}


void nrf_delay_ms(uint32_t volatile number_of_ms);

#endif
